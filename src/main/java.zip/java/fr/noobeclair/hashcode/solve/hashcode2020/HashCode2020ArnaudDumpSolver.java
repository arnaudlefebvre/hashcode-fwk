package fr.noobeclair.hashcode.solve.hashcode2020;

import fr.noobeclair.hashcode.bean.hashcode2020.HashCode2020BeanContainer;

public class HashCode2020ArnaudDumpSolver extends AbstractHashCode2020Solver {

    public HashCode2020ArnaudDumpSolver() {
        super();
    }

    @Override
    protected HashCode2020BeanContainer runWithStat(HashCode2020BeanContainer data) {
        HashCode2020BeanContainer datas = data;
        long start = System.currentTimeMillis();
        
        
        return datas;
    }

    @Override
    protected void addConfigStats() {
        // TODO Auto-generated method stub
        
    }

}
