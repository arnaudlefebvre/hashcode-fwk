/**
 * 
 */
package fr.noobeclair.hashcode.bean.hashcode2019;

import fr.noobeclair.hashcode.bean.config.Config;

/**
 * @author arnaud
 *
 */
public class H2019Config extends Config {
	
	/**
	 * 
	 */
	public H2019Config() {
		// TODO Auto-generated constructor stub
	}
	
}
