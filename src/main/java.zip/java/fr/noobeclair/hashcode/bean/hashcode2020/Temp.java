package fr.noobeclair.hashcode.bean.hashcode2020;

public class Temp {

    
    
}
