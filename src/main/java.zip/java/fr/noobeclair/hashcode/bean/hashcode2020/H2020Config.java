package fr.noobeclair.hashcode.bean.hashcode2020;

import fr.noobeclair.hashcode.bean.config.Config;

public class H2020Config  extends Config {
	
	public H2020Config() {
		
	}

}
