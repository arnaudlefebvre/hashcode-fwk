package fr.noobeclair.hashcode.bean.config;

public class ConfField {
	String name;
	String min;
	String max;
	String step;
	String[] excludes;
	String[] includes;
}
