package fr.noobeclair.hashcode.bean.hashcode2020;

import java.util.List;
import java.util.Map;

public class Out {

    private Map<Integer, List<Integer>> orderedSignupLibrairiesWithScannedBooks;

    public Map<Integer, List<Integer>> getOrderedSignupLibrairiesWithScannedBooks() {
        return orderedSignupLibrairiesWithScannedBooks;
    }

    public void setOrderedSignupLibrairiesWithScannedBooks(Map<Integer, List<Integer>> orderedSignupLibrairiesWithScannedBooks) {
        this.orderedSignupLibrairiesWithScannedBooks = orderedSignupLibrairiesWithScannedBooks;
    }
    
    
    
    
}
