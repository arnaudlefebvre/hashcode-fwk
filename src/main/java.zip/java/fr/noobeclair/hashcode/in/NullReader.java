package fr.noobeclair.hashcode.in;

import java.util.List;

import fr.noobeclair.hashcode.bean.BeanContainer;

public class NullReader extends InReader {

	public NullReader() {

	}

	@Override
	protected BeanContainer readFile(List lines, String in) {
		// TODO Auto-generated method stub
		return null;
	}

}
